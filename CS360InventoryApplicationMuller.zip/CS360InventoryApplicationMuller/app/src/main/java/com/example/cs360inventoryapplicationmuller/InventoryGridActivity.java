package com.example.cs360inventoryapplicationmuller;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class InventoryGridActivity extends AppCompatActivity {

    ArrayList<String> names, types, quantities;
    FloatingActionButton mFab, sFab;
    RecyclerView mRecyclerView;
    RecyclerViewAdapter mRecyclerAdapter;
    //Cursor cursor;
    DBHandler dbHandler;
    //SQLiteDatabase db = dbHandler.getWritableDatabase();


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_grid);

        dbHandler = new DBHandler(this);

        names = new ArrayList<>();
        types = new ArrayList<>();
        quantities = new ArrayList<>();


        //mRecyclerView = new RecyclerView(this);
        mRecyclerView = findViewById(R.id.inventory_recycler_view);

        mRecyclerAdapter = new RecyclerViewAdapter(this, names, quantities, types);
        // Set Layout Manager
        mRecyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        // Set Adapter
        mRecyclerView.setAdapter(mRecyclerAdapter);

        displayItems();

        mFab = (FloatingActionButton) findViewById(R.id.add_item_fab);
        mFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(InventoryGridActivity.this, AddItemActivity.class);
                startActivity(intent);
            }
        });

        sFab = (FloatingActionButton) findViewById(R.id.settings_fab);
        sFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(InventoryGridActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

    }


    public void displayItems(){
        Cursor cursor = dbHandler.getItems();
        if(cursor.getCount()==0){
            Toast.makeText(this, "No Items in Inventory", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            while(cursor.moveToNext()){
                names.add(cursor.getString(1));
                quantities.add(cursor.getString(2));
                types.add(cursor.getString(3));
            }
        }
    }
}