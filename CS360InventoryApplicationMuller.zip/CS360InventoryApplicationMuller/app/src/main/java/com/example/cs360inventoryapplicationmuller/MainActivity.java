package com.example.cs360inventoryapplicationmuller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText username, password;
    TextView loginFailed;
    Button login, createUser;
    DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.editTextUsername);
        password = (EditText) findViewById(R.id.editTextPassword);
        loginFailed = (TextView) findViewById(R.id.loginFailedText);
        dbHandler = new DBHandler(this);
        login =  (Button) findViewById(R.id.buttonLogin);
        createUser = (Button) findViewById(R.id.buttonCreateUser);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String un = username.getText().toString();
                String pw = password.getText().toString();

                if (un.equals("") || pw.equals("")){
                    Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                }
                else {
                    Boolean checkUser = dbHandler.checkUsernameAndPassword(un, pw);
                    if(checkUser==true){
                        Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, InventoryGridActivity.class);
                        startActivity(intent);
                        return;
                    }
                    else{
                        Toast.makeText(MainActivity.this, "No User Found", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        createUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String un = username.getText().toString().trim();
                String pw = password.getText().toString().trim();

                if (un.equals("") || pw.equals("")){
                    Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkUser = dbHandler.checkUsername(un);
                    if(checkUser==false){
                        dbHandler.addUser(un, pw);
                        Toast.makeText(MainActivity.this, "User Created Successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, InventoryGridActivity.class);
                        startActivity(intent);
                    }

                    else{
                        Toast.makeText(MainActivity.this, "User Already Exists", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}