package com.example.cs360inventoryapplicationmuller;

public class User {

    // Variables
    private int id;
    private String username;
    private String password;

    // Constructor
    public User(String un, String pw) {
        this.username = un;
        this.password = pw;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
