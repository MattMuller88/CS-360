package com.example.cs360inventoryapplicationmuller;

import static android.util.Half.NaN;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class AddItemActivity extends AppCompatActivity {

    private EditText itemNameEdt, itemQuantityEdt, itemTypeEdt;
    private Button addItemBt;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize variables
        itemNameEdt = findViewById(R.id.add_item_name);
        itemQuantityEdt = findViewById(R.id.add_item_quantity);
        itemTypeEdt = findViewById(R.id.add_item_type);
        addItemBt = findViewById(R.id.add_item_button);

        // Create instance of DBHandler class and pass context to it
        dbHandler = new DBHandler(AddItemActivity.this);


        addItemBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String itemName = itemNameEdt.getText().toString().trim();
                String itemQuantity = itemQuantityEdt.getText().toString().trim();
                String itemType = itemTypeEdt.getText().toString().trim();

                if (itemName.equals("") || itemQuantity.equals("") || itemType.equals("")){
                    Toast.makeText(AddItemActivity.this, "No Item Added \nPlease Enter All Fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    dbHandler.addItem(itemName, itemQuantity, itemType);
                    Toast.makeText(AddItemActivity.this, "Item has been added.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(AddItemActivity.this, InventoryGridActivity.class);
                    startActivity(intent);
                }

            }
        });
    }

}