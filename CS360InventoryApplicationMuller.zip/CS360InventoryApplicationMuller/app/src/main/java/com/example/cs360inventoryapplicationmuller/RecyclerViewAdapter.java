package com.example.cs360inventoryapplicationmuller;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;


import androidx.appcompat.view.menu.MenuView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    public Context mContext;
    public ArrayList<String> nameList, quantityList, typeList;

    public RecyclerViewAdapter(Context context, ArrayList<String> names, ArrayList<String> quantities, ArrayList<String> types) {
        this.mContext = context;
        this.nameList = names;
        this.quantityList = quantities;
        this.typeList = types;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // inflate the item Layout
        View view = LayoutInflater.from(mContext).inflate(R.layout.inventory_items, parent, false);
        // pass the view to View Holder
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.itemName.setText(nameList.get(position));
        holder.itemQuantity.setText(quantityList.get(position));
        holder.itemType.setText(typeList.get(position));
        String passingQuantity = holder.itemQuantity.getText().toString();
        String passingName = holder.itemName.getText().toString();
        holder.itemCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, EditItemActivity.class);
                Bundle b = new Bundle();
                b.putString("quantity", passingQuantity);
                b.putString("name", passingName);
                intent.putExtras(b);
                mContext.startActivity(intent);

            }
        });
    }


    @Override
    public int getItemCount() {
        return nameList.size();
    }



    public static class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView itemName, itemQuantity, itemType;
        public CardView itemCard;

        public MyViewHolder(View v) {
            super(v);
            itemName = (TextView) v.findViewById(R.id.item_name);
            itemQuantity = (TextView) v.findViewById(R.id.item_quantity);
            itemType = (TextView) v.findViewById(R.id.item_type);
            itemCard = (CardView) v.findViewById(R.id.item_card_view);
        }

    }

}
