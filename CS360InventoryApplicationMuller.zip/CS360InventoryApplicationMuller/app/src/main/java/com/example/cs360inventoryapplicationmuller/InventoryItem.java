package com.example.cs360inventoryapplicationmuller;


public class InventoryItem {

    public String itemName;
    public String itemType;
    public int itemQuantity;

    // Constructor
    public InventoryItem(String name, int quantity, String type){
        itemName = name;
        itemQuantity = quantity;
        itemType = type;
    }

    // Getters
    public String getItemName() {
        return itemName;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public String getItemType() {
        return itemType;
    }

    // Setters
    public void setItemName(String name) {
        itemName = name;
    }

    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }
}
