package com.example.cs360inventoryapplicationmuller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    // Create constant variables for database
    private static final int DATABASE_VERSION = 2;
    private static final String inventoryDBName = "Inventory.db";
    private static final String usersTableName = "Users";
    private static final String inventoryTableName = "Inventory";
    private static final String usernameColumn = "username";
    private static final String passwordColumn = "password";
    private static final String itemNameColumn = "itemName";
    private static final String itemQuantityColumn = "itemQuantity";
    private static final String itemTypeColumn = "itemType";

    // Create queries to create tables
    private String usersTableQuery = "CREATE TABLE " + usersTableName + " ("
            //+ idColumn + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + usernameColumn + " TEXT,"
            + passwordColumn + " TEXT)";

    private String inventoryTableQuery = "CREATE TABLE " + inventoryTableName + " ("
            //+ idColumn + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + itemNameColumn + " TEXT,"
            + itemQuantityColumn + " TEXT,"
            + itemTypeColumn + " TEXT)";

    // Constructor
    public DBHandler(@Nullable Context context) {
        super(context, inventoryDBName, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Execute queries
        db.execSQL(usersTableQuery);
        db.execSQL(inventoryTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS usersTableName");
        db.execSQL("DROP TABLE IF EXISTS " + inventoryTableName);
        onCreate(db);
    }

    public Cursor getItems(){
       // ArrayList<InventoryItem> itemList = new ArrayList<InventoryItem>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + inventoryTableName, null);

        return cursor;
    }


    // Method for checking database for user upon login
    public boolean checkUsernameAndPassword(String un, String pw){
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {
                usernameColumn
        };

        String selection = usernameColumn + " = ? AND " + passwordColumn + " = ?";

        String[] selectionArgs = {un, pw};

        Cursor cursor = db.query(usersTableName, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();


        if (cursorCount > 0) {
            return true;
        }
        else {
            return false;
        }

    }

    // Method for checking database for user upon login
    public boolean checkUsername(String un){
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {
                usernameColumn
        };

        String selection = usernameColumn + " = ?";

        String[] selectionArgs = {un};

        Cursor cursor = db.query(usersTableName, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }
        return false;
    }

    // Method for adding new user to database
    public void addUser(String un, String pw){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(usernameColumn, un);
        values.put(passwordColumn, pw);

        db.insert(usersTableName, null, values);
        db.close();

    }

    // Method for adding new inventory item
    public void addItem(String itemName, String itemQuantity, String itemType){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(itemNameColumn, itemName);
        values.put(itemQuantityColumn, itemQuantity);
        values.put(itemTypeColumn, itemType);

        db.insert(inventoryTableName, null, values);

        db.close();
    }

    public void updateItem(String itemName, String itemQuantity){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(itemQuantityColumn, itemQuantity);

        String[] args = {itemName};

        db.update(inventoryTableName, values, itemNameColumn + " LIKE ?", args);

        db.close();
    }

    public void deleteItem(String itemName){
        SQLiteDatabase db = this.getWritableDatabase();

        String[] args = {itemName};

        db.delete(inventoryTableName, itemNameColumn + " LIKE ?", args);

        db.close();
    }

}
