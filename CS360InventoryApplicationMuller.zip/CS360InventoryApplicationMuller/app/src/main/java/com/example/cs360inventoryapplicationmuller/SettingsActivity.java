package com.example.cs360inventoryapplicationmuller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity {

    RadioGroup yesNo;
    Button yes, no, addNumber;
    EditText editNumber;
    TextView prompt;
    Boolean permission;
    String number;
    Bundle bundle;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        yesNo = findViewById(R.id.sms_permission_radio);
        yes = findViewById(R.id.radioButtonYes);
        no = findViewById(R.id.radioButtonNo);
        addNumber = findViewById(R.id.buttonAddNumber);
        editNumber = findViewById(R.id.editTextPhoneNumber);
        prompt = findViewById(R.id.textViewEnterNumber);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                yesNo.check(R.id.radioButtonYes);
                addNumber.setVisibility(View.VISIBLE);
                editNumber.setVisibility(View.VISIBLE);
                prompt.setVisibility(View.VISIBLE);
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                permission = false;

                addNumber.setVisibility(View.INVISIBLE);
                editNumber.setVisibility(View.INVISIBLE);
                prompt.setVisibility(View.INVISIBLE);
            }
        });

        addNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number = editNumber.getText().toString();
                if(number.length() != 10){
                    Toast.makeText(SettingsActivity.this, "Please enter a 10 digit phone number", Toast.LENGTH_SHORT).show();
                }
                else{
                    permission = true;
                    Toast.makeText(SettingsActivity.this, "Phone Number Added", Toast.LENGTH_SHORT).show();

                    bundle = new Bundle(savedInstanceState);
                    bundle.putString("number", number);
                    bundle.putBoolean("permission", permission);


                    Intent intent = new Intent(SettingsActivity.this, InventoryGridActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        });
    }

}