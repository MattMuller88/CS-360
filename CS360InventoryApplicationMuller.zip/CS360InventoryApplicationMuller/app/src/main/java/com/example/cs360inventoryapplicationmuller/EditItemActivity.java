package com.example.cs360inventoryapplicationmuller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class EditItemActivity extends AppCompatActivity {

    EditText itemQuantity;
    TextView itemName;
    Button updateItem, deleteItem;
    DBHandler dbHandler;
    Boolean permission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        itemName = (TextView) findViewById(R.id.text_item_name);
        itemQuantity = (EditText) findViewById(R.id.edit_text_quantity);
        updateItem = (Button) findViewById(R.id.buttonUpdateItem);
        deleteItem = (Button) findViewById(R.id.buttonDeleteItem);
        dbHandler = new DBHandler(this);

        Bundle b = getIntent().getExtras();
        String receivingName = b.getString("name");
        String receivingQuantity = b.getString("quantity");
        itemName.setText(receivingName);
        itemQuantity.setText(receivingQuantity);

        updateItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String passingQuantity = itemQuantity.getText().toString().trim();
                String passingName = itemName.getText().toString();
                dbHandler.updateItem(passingName, passingQuantity);

                if(passingQuantity == "0"){

                     sendSMSNotification(view);

                }

                Intent intent = new Intent(EditItemActivity.this, InventoryGridActivity.class);
                startActivity(intent);
            }
        });

        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String passingName = itemName.getText().toString();
                dbHandler.deleteItem(passingName);
                Intent intent = new Intent(EditItemActivity.this, InventoryGridActivity.class);
                startActivity(intent);
            }
        });



    }
    public void sendSMSNotification(View view) {
        String item = itemName.getText().toString();
        String notification = "Item: " + item + " is out of stock";

        SettingsActivity settingsActivity = new SettingsActivity();
        Bundle b = settingsActivity.bundle;
        String phoneNum = b.getString("number");
        permission = b.getBoolean("permission");
        try {
            if(permission==true) {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNum, null, notification, null, null);
                Toast.makeText(EditItemActivity.this, "Low Inventory Notification sent", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(EditItemActivity.this, "Low Inventory Notifications are Disabled", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(EditItemActivity.this, "Failed to Send Notification", Toast.LENGTH_SHORT).show();
        }
    }
}